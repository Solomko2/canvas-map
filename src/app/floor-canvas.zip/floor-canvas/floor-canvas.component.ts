import {AfterViewInit, Component, Input, OnInit, ViewChild} from '@angular/core';
import {IFloorCanvasOption} from '../models/IFloorCanvasOption';
import * as Konva from 'konva';

@Component({
  selector: 'app-floor-canvas',
  templateUrl: './floor-canvas.component.html',
  styleUrls: ['./floor-canvas.component.css']
})
export class FloorCanvasComponent implements OnInit, AfterViewInit {
  @Input() options: IFloorCanvasOption;
  @ViewChild('floor') canvas: any;

  constructor() {
  }

  ngOnInit() {}

  ngAfterViewInit() {
    this._initCanvas();
  }

  private _initCanvas() {
    const width = this.options.width,
      height = this.options.height,
      stage = new Konva.Stage({
        container: this.canvas.nativeElement,
        width: width,
        height: height
      });
    const layer = new Konva.Layer();
    const imageObj = new Image();

    imageObj.onload = () => {
      const floor = new Konva.Image({
        x: 0,
        y: 0,
        image: imageObj,
        width: width,
        height: height
      });
      layer.add(floor);
      stage.add(layer);
    };
    imageObj.src = this.options.imgSrc;
  }

}
