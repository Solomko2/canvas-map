export interface IFloorCanvasOption {
  imgSrc: string;
  points: any[];
}
